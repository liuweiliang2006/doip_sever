/*  BEGIN_FILE_HDR
********************************************************************************
*   NOTICE                              
*   This software is the property of HiRain Technologies. Any information 
*   contained in this doc should not be reproduced, or used, or disclosed 
*   without the written authorization from HiRain Technologies.
********************************************************************************
*   File Name       : MemMap.h
********************************************************************************
*   Project/Product : AUTOSAR BSW PROJECT
*   Title           : MemMap module configuration File
*   Author          : Hirain
********************************************************************************
*   Description     : MemMap module configuration File
*
********************************************************************************
*   Limitations     : None
*
********************************************************************************
*
********************************************************************************
*   Revision History:
* 
*   Version     Date          Initials      CR#          Descriptions
*   ---------   ----------    ------------  ----------   ---------------
*   1.0.0       18/10/2017    Eas           N/A          N/A
*
********************************************************************************
* END_FILE_HDR*/
#if defined (START_WITH_IF)
#endif /* START_WITH_IF */ 
